Este directorio contiene código para ayudaros a segmentar una imagen.

Archivos:

select_pixels.py    Funciones para pintar encima de una imagen

pinta_colores.py    Ejemplo para mostrar la distribución de color de los píxeles marcados

etiqueta_imagenes   Esqueleto de programa para sacar los datos de entrenamiento del
		    el algoritmo de segmentación.

pract_run	    Esqueleto de programa para ejecutar el algoritmo de segmentación.
		    Este programa primero entrena el clasificador con los datos de
 		    entrenamiento y luego segmenta el vídeo.
